export {};

declare global {
  interface Window {
    hljs: any;
  }
}

import { CSSItem, JSItem } from '../../../markmap-common';
import { ITransformer } from '../types';
/**
 * Find NPM paths and resolve them to full URLs with the same package version as in this library.
 */
export declare function addDefaultVersions(paths: string[], name: string, version: string): string[];
export declare function patchJSItem(transformer: ITransformer, item: JSItem): JSItem;
export declare function patchCSSItem(transformer: ITransformer, item: CSSItem): CSSItem;

declare const _default: import("../types").ITransformPlugin;
export default _default;

declare const plugin: import("../types").ITransformPlugin;
export default plugin;

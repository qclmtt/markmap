export declare const name = "hljs";
export declare const config: {
    versions: {
        hljs: string;
    };
    preloadScripts: import("../../../markmap-common").JSScriptItem[];
    styles: import("../../../markmap-common").CSSStylesheetItem[];
};

export * from './base';
export declare const plugins: import("..").ITransformPlugin[];

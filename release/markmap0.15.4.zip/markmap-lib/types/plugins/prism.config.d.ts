export declare const name = "prism";
export declare const config: {
    versions: {
        prismjs: string;
    };
    preloadScripts: import("../../../markmap-common").JSScriptItem[];
    styles: import("../../../markmap-common").CSSStylesheetItem[];
};

export declare const template: string;
export declare const baseJsPaths: string[];

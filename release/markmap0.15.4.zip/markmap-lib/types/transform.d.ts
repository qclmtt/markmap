import { Remarkable } from 'remarkable';
import { UrlBuilder, JSItem, IMarkmapOptions, IMarkmapJSONOptions, IPureNode } from '../../markmap-common';
import { ITransformResult, ITransformPlugin, IAssets, ITransformHooks, IFeatures, ITransformer } from './types';
import { plugins as builtInPlugins } from './plugins';
export { builtInPlugins };
export declare class Transformer implements ITransformer {
    hooks: ITransformHooks;
    md: Remarkable;
    assetsMap: Record<string, IAssets>;
    urlBuilder: UrlBuilder;
    plugins: ITransformPlugin[];
    constructor(plugins?: Array<ITransformPlugin | (() => ITransformPlugin)>);
    buildTree(tokens: Remarkable.Token[]): IPureNode;
    transform(content: string): ITransformResult;
    /**
     * Get all assets from enabled plugins or filter them by plugin names as keys.
     */
    getAssets(keys?: string[]): IAssets;
    /**
     * Get used assets by features object returned by `transform`.
     */
    getUsedAssets(features: IFeatures): IAssets;
    fillTemplate(root: IPureNode | null, assets: IAssets, extra?: {
        baseJs?: JSItem[];
        jsonOptions?: IMarkmapJSONOptions;
        getOptions?: (jsonOptions: IMarkmapJSONOptions) => Partial<IMarkmapOptions>;
    }): string;
}

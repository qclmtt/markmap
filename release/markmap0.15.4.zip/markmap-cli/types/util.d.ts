import { IAssets, ITransformer } from '../../markmap-lib';
export interface IDevelopOptions {
    /**
     * Whether to open the generated markmap in browser
     */
    open: boolean;
    /**
     * Whether to show the default toolbar
     */
    toolbar: boolean;
    /**
     * Whether to inline all assets to make the HTML work offline.
     * Ignored in watching mode.
     */
    offline: boolean;
}
export declare function addToolbar(transformer: ITransformer, assets: IAssets): IAssets;
export declare function localProvider(path: string): string;
export declare function resolveFile(relpath: string): Promise<string>;

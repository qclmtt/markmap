import { IDevelopOptions } from './util';
interface IFileUpdate {
    ts?: number;
    content?: string;
    line?: number;
}
interface IContentProvider {
    getUpdate: (ts: number, timeout?: number) => Promise<IFileUpdate>;
    setContent: (content: string) => void;
    setCursor: (line: number) => void;
    dispose: () => void;
}
export declare function develop(fileName: string | undefined, options: IDevelopOptions): Promise<{
    provider: IContentProvider;
    close(): Promise<void>;
}>;
export {};

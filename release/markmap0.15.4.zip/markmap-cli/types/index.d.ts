import { type IMarkmapCreateOptions } from '../../markmap-lib';
import { IDevelopOptions } from './util';
import { develop } from './dev-server';
export * from '../../markmap-lib';
export { develop };
export declare function createMarkmap(options: IMarkmapCreateOptions & IDevelopOptions): Promise<void>;
export declare function main(): Promise<void>;

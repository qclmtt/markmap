# markmap-common

Common types and utility functions used by markmap packages.

declare interface Window {
  markmap: unknown;
}

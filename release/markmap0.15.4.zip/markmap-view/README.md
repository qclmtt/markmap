# markmap-view

![NPM](https://img.shields.io/npm/v/markmap-view.svg)
![License](https://img.shields.io/npm/l/markmap-view.svg)
![Downloads](https://img.shields.io/npm/dt/markmap-view.svg)

View markmaps in browser.

This package is separated from [markmap-lib](https://github.com/gera2ld/markmap/tree/master/packages/markmap-lib) to decrease the size of `node_modules` because you don't need this in `node_modules` most of the time.

👉 [Read the documentation](https://markmap.js.org/docs) for more detail.
